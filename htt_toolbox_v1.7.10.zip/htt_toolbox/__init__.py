bl_info = {
    "name": "HTT 工具箱 (HTT Toolbox)",
    "author": "花提提",
    "version": (1, 7, 10),
    "blender": (4, 2, 0),
    "location": "3D Viewport > Sidebar > htt工具箱",
    "description": "渲染测试与动画阴影检查工具集合",
    "category": "3D View",
}

import math
import os
import hashlib
import statistics
from array import array

import bpy
from bpy.props import EnumProperty, FloatProperty, IntProperty, PointerProperty, StringProperty
from bpy.types import Operator, Panel, PropertyGroup


ADDON_VERSION = "1.7.10"

_SHADOW_FIX_BACKUP = {}
_HIGHLIGHT_BACKUP = {}
_LIGHT_HIGHLIGHT_BACKUP = {}
_LIGHT_LINK_BACKUP = {}

_DATA_LAYOUT_REV = "HUxUVFDuvkoTxVwg"
_RANGE_TABLE_ID = "V2Y6kNZeERfgntFQJshT7naMmuske2ZxeLc"
_INTERNAL_SCHEMA_DIGEST = "7ce2ea7c9641db78b5d15b42be004cd45fa46742a0e1b27309bd583ad1d7235c"


def _eevee_engine():
    return 'BLENDER_EEVEE' if bpy.app.version >= (5, 0, 0) else 'BLENDER_EEVEE_NEXT'


def _compositor_tree(scene, create=False):
    if hasattr(scene, 'compositing_node_group'):
        tree = scene.compositing_node_group
        if tree is None and create:
            tree = bpy.data.node_groups.new(f"{scene.name} 合成器", 'CompositorNodeTree')
            scene.compositing_node_group = tree
        return tree
    if create:
        scene.use_nodes = True
    return getattr(scene, 'node_tree', None)


def _frame_ranges(frames):
    """Turn frame numbers into compact text such as 1-4, 8, 12-15."""
    values = sorted(set(frames))
    if not values:
        return "无"
    ranges = []
    start = previous = values[0]
    for frame in values[1:]:
        if frame == previous + 1:
            previous = frame
            continue
        ranges.append(str(start) if start == previous else f"{start}-{previous}")
        start = previous = frame
    ranges.append(str(start) if start == previous else f"{start}-{previous}")
    return ", ".join(ranges)


_TOPOLOGY_CACHE_ID = "7hvrWu3UzFXLnGKVp1CwbpNP75LYbIVyif7n"


_ANALYSIS_DATA_ID = "BLXRLODov1hiR4ZDHhlbu7cW81l32qdftBSE"


class HTT_ToolboxSettings(PropertyGroup):
    render_test_mode: EnumProperty(
        name="测试方式",
        items=(
            ('SINGLE', "单帧", "渲染指定一帧 PNG 图片"),
            ('RANGE', "帧范围", "渲染指定范围的 PNG 序列或 MOV 视频"),
        ),
        default='SINGLE',
    )
    render_output_dir: StringProperty(name="输出目录", subtype='DIR_PATH', default="//htt_render_test/")
    render_test_frame: IntProperty(name="测试帧", default=1, min=0)
    render_range_start: IntProperty(name="起始帧", default=1, min=0)
    render_range_end: IntProperty(name="结束帧", default=10, min=0)
    render_range_format: EnumProperty(
        name="范围格式",
        items=(
            ('PNG', "PNG 序列", "每帧输出一张 PNG 图片"),
            ('MOV', "MOV 视频", "输出 H.264 编码的 QuickTime MOV 视频"),
        ),
        default='PNG',
    )
    shadow_check_start: IntProperty(name="起始帧", default=1, min=0)
    shadow_check_end: IntProperty(name="结束帧", default=250, min=0)
    shadow_check_quality: EnumProperty(
        name="检查精度",
        description="快速用 25% 分辨率，标准用 50%，最终确认用项目完整分辨率；超长范围自动抽样",
        items=(
            ('QUICK', "快速", "25% 分辨率，最多 60 帧；只用于初筛"),
            ('STANDARD', "标准", "50% 分辨率，最多 120 帧；兼顾速度与画面代表性"),
            ('FINAL', "最终", "使用项目完整分辨率，最多 240 帧；用于确认最终渲染风险"),
        ),
        default='STANDARD',
    )
    shadow_flicker_sensitivity: FloatProperty(
        name="闪烁敏感度",
        description="越小越容易报告画面暗部突变；0.06 是建议起点，不代表绝对正确",
        default=0.06,
        min=0.01,
        max=0.30,
        subtype='FACTOR',
    )
    shadow_check_report: StringProperty(name="阴影检查结果", default="")
    shadow_check_status: StringProperty(name="检查状态", default="")
    shadow_resolution_target: EnumProperty(
        name="目标分辨率",
        description="降低全局阴影贴图分辨率以减轻 Shadow Pool 压力",
        items=(
            ('0.75', "75%", "轻度降低，建议先尝试"),
            ('0.50', "50%", "中度降低，阴影边缘可能变软"),
            ('0.25', "25%", "大幅降低，仅在容量压力严重时使用"),
        ),
        default='0.75',
    )


_FIELD_PROFILE_ID = "SCtPHR31xRBcYS1vx4rqnMsto4UeY4oDLCa5"


class HTT_OT_render_test(Operator):
    bl_idname = "htt_toolbox.render_test"
    bl_label = "开始渲染测试"
    bl_description = "按当前引擎与采样设置渲染指定单帧或范围；会写入所选目录，不修改模型，结束后恢复原输出设置"

    def execute(self, context):
        scene = context.scene
        settings = scene.htt_toolbox
        output_dir = bpy.path.abspath(settings.render_output_dir).strip()
        if not output_dir:
            self.report({'WARNING'}, "请选择输出目录")
            return {'CANCELLED'}
        if settings.render_test_mode == 'RANGE' and settings.render_range_end < settings.render_range_start:
            self.report({'WARNING'}, "结束帧不能小于起始帧")
            return {'CANCELLED'}
        try:
            os.makedirs(output_dir, exist_ok=True)
        except OSError as exc:
            self.report({'ERROR'}, f"无法创建输出目录：{exc}")
            return {'CANCELLED'}

        render = scene.render
        image = render.image_settings
        saved = {
            "filepath": render.filepath,
            "use_file_extension": render.use_file_extension,
            "file_format": image.file_format,
            "color_mode": image.color_mode,
            "color_depth": image.color_depth,
            "frame_start": scene.frame_start,
            "frame_end": scene.frame_end,
            "frame_current": scene.frame_current,
            "ffmpeg_format": render.ffmpeg.format,
            "ffmpeg_codec": render.ffmpeg.codec,
        }

        try:
            if settings.render_test_mode == 'SINGLE':
                frame = settings.render_test_frame
                scene.frame_set(frame)
                image.file_format = 'PNG'
                image.color_mode = 'RGBA' if render.film_transparent else 'RGB'
                image.color_depth = '8'
                render.use_file_extension = True
                render.filepath = os.path.join(output_dir, f"htt_test_{frame:04d}.png")
                bpy.ops.render.render(write_still=True)
                result_path = render.filepath
            else:
                scene.frame_start = settings.render_range_start
                scene.frame_end = settings.render_range_end
                if settings.render_range_format == 'PNG':
                    image.file_format = 'PNG'
                    image.color_mode = 'RGBA' if render.film_transparent else 'RGB'
                    image.color_depth = '8'
                    render.use_file_extension = True
                    render.filepath = os.path.join(output_dir, "htt_test_")
                    result_path = output_dir
                else:
                    image.file_format = 'FFMPEG'
                    render.ffmpeg.format = 'QUICKTIME'
                    render.ffmpeg.codec = 'H264'
                    render.use_file_extension = False
                    render.filepath = os.path.join(output_dir, "htt_test.mov")
                    result_path = render.filepath
                bpy.ops.render.render(animation=True)
        except RuntimeError as exc:
            self.report({'ERROR'}, f"渲染失败：{exc}")
            return {'CANCELLED'}
        finally:
            render.filepath = saved["filepath"]
            render.use_file_extension = saved["use_file_extension"]
            image.file_format = saved["file_format"]
            image.color_mode = saved["color_mode"]
            image.color_depth = saved["color_depth"]
            render.ffmpeg.format = saved["ffmpeg_format"]
            render.ffmpeg.codec = saved["ffmpeg_codec"]
            scene.frame_start = saved["frame_start"]
            scene.frame_end = saved["frame_end"]
            scene.frame_set(saved["frame_current"])

        self.report({'INFO'}, f"渲染测试完成：{result_path}")
        if not bpy.app.background:
            mode = settings.render_test_mode
            if mode == 'SINGLE':
                summary = f"单帧 PNG 已完成：第 {settings.render_test_frame} 帧"
                location = result_path
            elif settings.render_range_format == 'PNG':
                summary = f"PNG 序列已完成：{settings.render_range_start}-{settings.render_range_end} 帧"
                location = result_path
            else:
                summary = f"MOV 视频已完成：{settings.render_range_start}-{settings.render_range_end} 帧"
                location = result_path

            def draw_popup(menu, _context):
                menu.layout.label(text=summary, icon='CHECKMARK')
                menu.layout.label(text="保存位置：")
                menu.layout.label(text=location, icon='FILE_FOLDER')

            context.window_manager.popup_menu(draw_popup, title="HTT 渲染完成", icon='CHECKMARK')
        return {'FINISHED'}


_VOXEL_LAYOUT_ID = "kRJWWLCyIu87h2mxvYpQkykAkTol0HmezMOZ"


class HTT_OT_check_shadow_range(Operator):
    bl_idname = "htt_toolbox.check_shadow_range"
    bl_label = "检查最终渲染阴影"
    bl_description = "按当前相机、灯光、材质和 Eevee 设置抽样渲染整幅画面；只生成临时结果，不写文件，Esc 可在帧间取消"

    _timer = None

    def _prepare(self, context):
        scene = context.scene
        settings = scene.htt_toolbox
        if settings.shadow_check_end < settings.shadow_check_start:
            self.report({'WARNING'}, "结束帧不能小于起始帧")
            return False
        if scene.camera is None:
            self.report({'WARNING'}, "场景没有活动相机，无法检查最终画面")
            return False
        profiles = {
            'QUICK': (25, 10, 60),
            'STANDARD': (50, 3, 120),
            'FINAL': (scene.render.resolution_percentage, 1, 240),
        }
        percent, base_step, maximum = profiles[settings.shadow_check_quality]
        count = settings.shadow_check_end - settings.shadow_check_start + 1
        self._step = max(base_step, math.ceil(count / maximum))
        self._frames = list(range(settings.shadow_check_start, settings.shadow_check_end + 1, self._step))
        if self._frames[-1] != settings.shadow_check_end:
            self._frames.append(settings.shadow_check_end)
        self._index = 0
        self._previous = None
        self._transitions = []
        self._original_frame = scene.frame_current
        self._original_percent = scene.render.resolution_percentage
        self._used_percent = percent
        self._engine = scene.render.engine
        self._pool_size = None
        self._shadow_scale = None
        if self._engine == _eevee_engine():
            self._pool_size = int(scene.eevee.shadow_pool_size)
            self._shadow_scale = scene.eevee.shadow_resolution_scale
        scene.render.resolution_percentage = percent
        settings.shadow_check_status = f"准备检查 {len(self._frames)} 帧…"
        settings.shadow_check_report = ""
        return True

    @staticmethod
    def _read_luminance():
        # Read the render buffer directly. Blender 5.x moved the compositor to a
        # standalone node group, and creating a temporary Viewer node is both
        # unnecessary and sensitive to compositor API changes.
        image = bpy.data.images.get("Render Result")
        if image is None or image.size[0] == 0 or image.size[1] == 0:
            raise RuntimeError("没有取得 Render Result")
        total = len(image.pixels)
        if total < 4:
            raise RuntimeError("Render Result 没有可读取的像素")
        pixels = array('f', [0.0]) * total
        image.pixels.foreach_get(pixels)
        pixel_count = total // 4
        stride = max(1, math.ceil(pixel_count / 20000))
        values = []
        for pixel in range(0, pixel_count, stride):
            index = pixel * 4
            values.append(0.2126 * pixels[index] + 0.7152 * pixels[index + 1] + 0.0722 * pixels[index + 2])
        return values

    def _process_next(self, context):
        scene = context.scene
        settings = scene.htt_toolbox
        frame = self._frames[self._index]
        scene.frame_set(frame)
        settings.shadow_check_status = f"正在渲染 {frame} 帧（{self._index + 1}/{len(self._frames)}）"
        bpy.ops.render.render(write_still=False)
        current = self._read_luminance()
        if self._previous is not None and len(current) == len(self._previous):
            differences = [abs(a - b) for a, b in zip(current, self._previous)]
            mean_difference = sum(differences) / len(differences)
            dark_changed = sum(
                1 for a, b, difference in zip(current, self._previous, differences)
                if difference > 0.12 and min(a, b) < 0.55
            ) / len(differences)
            self._transitions.append((frame, mean_difference, dark_changed))
        self._previous = current
        self._index += 1

    def _restore(self, context):
        context.scene.render.resolution_percentage = self._original_percent
        context.scene.frame_set(self._original_frame)
        if self._timer is not None:
            context.window_manager.event_timer_remove(self._timer)
            self._timer = None

    def _finish_report(self, context, cancelled=False):
        settings = context.scene.htt_toolbox
        scores = [mean + dark * 0.5 for _frame, mean, dark in self._transitions]
        median_score = statistics.median(scores) if scores else 0.0
        deviations = [abs(score - median_score) for score in scores]
        mad = statistics.median(deviations) if deviations else 0.0
        threshold = median_score + max(settings.shadow_flicker_sensitivity, mad * 4.0)
        suspicious = [
            frame for (frame, mean, dark), score in zip(self._transitions, scores)
            if score > threshold and dark > 0.01
        ]
        lines = [
            f"HTT 最终画面检查：{settings.shadow_check_start}-{settings.shadow_check_end}，"
            f"实际步长 {self._step}，渲染 {self._index}/{len(self._frames)} 帧，分辨率 {self._used_percent}%"
        ]
        if cancelled:
            lines.append("[警告] 检查已取消，以下结果只覆盖已完成的采样帧。")
            lines.append("[处理] 缩短帧范围或选择快速档后重新检查。")
        if self._engine == _eevee_engine():
            lights = sum(1 for obj in context.scene.objects if obj.type == 'LIGHT' and not obj.hide_render)
            lines.append(f"[通过] Eevee 阴影池 {self._pool_size} MB；阴影分辨率比例 {self._shadow_scale:.2f}；可渲染灯光 {lights} 个。")
            if self._pool_size <= 512 and (lights >= 4 or self._shadow_scale > 1.0):
                lines.append("[警告] 当前阴影池配置存在容量压力，复杂镜头可能出现阴影缺块或闪烁。")
                lines.append("[处理] 在“渲染属性 → 性能 → 阴影”增大 Shadow Pool Size；512 MB 可先试 1024 MB，再用最终档复查。")
        else:
            lines.append("[警告] 当前不是 Eevee Next，无法判断 Eevee Shadow Pool 风险。")
            lines.append("[处理] 若最终使用 Eevee，请切换到 Eevee 后再检查；Cycles 没有同一套 Shadow Pool。")
        if suspicious:
            lines.append(f"[警告] 疑似整幅画面阴影/暗部突变帧：{_frame_ranges(suspicious)}")
            lines.append("[处理] 分别渲染异常帧及其前一帧对比；优先增大阴影池，再检查灯光、相机、材质和降噪动画。")
        elif self._index >= 2:
            lines.append("[通过] 已采样画面未发现明显的异常暗部跳变。")
            lines.append("[处理] 抽样不能证明所有帧正常；交付前用最终档检查完整关键范围。")
        settings.shadow_check_report = "\n".join(lines)
        settings.shadow_check_status = "已取消" if cancelled else "检查完成"
        print("\n" + settings.shadow_check_report + "\n")

    def execute(self, context):
        if not self._prepare(context):
            return {'CANCELLED'}
        try:
            while self._index < len(self._frames):
                self._process_next(context)
            self._finish_report(context)
        except Exception as exc:
            self.report({'ERROR'}, f"检查失败：{exc}")
            return {'CANCELLED'}
        finally:
            self._restore(context)
        return {'FINISHED'}

    def invoke(self, context, _event):
        if bpy.app.background:
            return self.execute(context)
        if not self._prepare(context):
            return {'CANCELLED'}
        self._timer = context.window_manager.event_timer_add(0.1, window=context.window)
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type == 'ESC':
            self._finish_report(context, cancelled=True)
            self._restore(context)
            return {'CANCELLED'}
        if event.type != 'TIMER':
            return {'PASS_THROUGH'}
        try:
            self._process_next(context)
        except RuntimeError as exc:
            self.report({'ERROR'}, f"检查失败：{exc}")
            self._restore(context)
            return {'CANCELLED'}
        if self._index >= len(self._frames):
            self._finish_report(context)
            self._restore(context)
            return {'FINISHED'}
        return {'RUNNING_MODAL'}


class HTT_OT_check_shadow_fast(Operator):
    bl_idname = "htt_toolbox.check_shadow_fast"
    bl_label = "无渲染快速检查"
    bl_description = "只推进时间轴，不渲染图片；快速检查阴影池配置以及灯光投影、能量、可见性和变换跳变，完成后恢复原帧"

    def execute(self, context):
        scene = context.scene
        settings = scene.htt_toolbox
        if settings.shadow_check_end < settings.shadow_check_start:
            self.report({'WARNING'}, "结束帧不能小于起始帧")
            return {'CANCELLED'}
        profiles = {
            'QUICK': (10, 60),
            'STANDARD': (3, 200),
            'FINAL': (1, 500),
        }
        base_step, maximum = profiles[settings.shadow_check_quality]
        count = settings.shadow_check_end - settings.shadow_check_start + 1
        step = max(base_step, math.ceil(count / maximum))
        frames = list(range(settings.shadow_check_start, settings.shadow_check_end + 1, step))
        if frames[-1] != settings.shadow_check_end:
            frames.append(settings.shadow_check_end)

        issues = {
            "投影灯光数量变化": [],
            "灯光开启或关闭投影": [],
            "灯光能量突然变化": [],
            "灯光位置或角度突然变化": [],
        }
        original_frame = scene.frame_current
        previous = None
        settings.shadow_check_status = f"正在无渲染检查 {len(frames)} 帧…"
        try:
            for frame in frames:
                scene.frame_set(frame)
                context.view_layer.update()
                current = {}
                for obj in scene.objects:
                    if obj.type != 'LIGHT':
                        continue
                    current[obj.name] = {
                        "active": not obj.hide_render and obj.data.use_shadow and obj.data.energy > 0.0,
                        "use_shadow": obj.data.use_shadow,
                        "energy": obj.data.energy,
                        "location": obj.matrix_world.translation.copy(),
                        "rotation": obj.matrix_world.to_quaternion(),
                    }
                if previous is not None:
                    active_now = sum(item["active"] for item in current.values())
                    active_before = sum(item["active"] for item in previous.values())
                    if active_now != active_before:
                        issues["投影灯光数量变化"].append(frame)
                    for name in current.keys() & previous.keys():
                        now = current[name]
                        before = previous[name]
                        if now["use_shadow"] != before["use_shadow"]:
                            issues["灯光开启或关闭投影"].append(frame)
                        denominator = max(abs(before["energy"]), 1.0)
                        if abs(now["energy"] - before["energy"]) / denominator > 0.5:
                            issues["灯光能量突然变化"].append(frame)
                        position_jump = (now["location"] - before["location"]).length
                        angle_jump = now["rotation"].rotation_difference(before["rotation"]).angle
                        if position_jump > 10.0 or angle_jump > math.radians(45.0):
                            issues["灯光位置或角度突然变化"].append(frame)
                previous = current
        finally:
            scene.frame_set(original_frame)

        lines = [
            f"HTT 无渲染检查：{settings.shadow_check_start}-{settings.shadow_check_end}，"
            f"实际步长 {step}，采样 {len(frames)} 帧"
        ]
        if scene.render.engine == _eevee_engine():
            pool = int(scene.eevee.shadow_pool_size)
            scale = scene.eevee.shadow_resolution_scale
            lights = sum(1 for obj in scene.objects if obj.type == 'LIGHT' and not obj.hide_render and obj.data.use_shadow)
            lines.append(f"[通过] Eevee 阴影池 {pool} MB；阴影分辨率比例 {scale:.2f}；投影灯光 {lights} 个。")
            if pool <= 512 and (lights >= 4 or scale > 1.0):
                lines.append("[警告] 当前配置存在阴影池容量压力。")
                lines.append("[处理] 优先使用“阴影池提升一级”，然后重新快速检查。")
        else:
            lines.append("[警告] 当前不是 Eevee Next，无法判断 Eevee Shadow Pool 风险。")
            lines.append("[处理] 如果最终使用 Eevee，请切换渲染引擎后重新检查。")

        advice = {
            "投影灯光数量变化": "检查灯光的渲染可见性、能量关键帧以及驱动器。",
            "灯光开启或关闭投影": "检查灯光 Use Shadow 的关键帧，避免非预期切换。",
            "灯光能量突然变化": "检查灯光 Energy 曲线，必要时改用平滑插值。",
            "灯光位置或角度突然变化": "检查灯光位置、旋转、父级和约束切换；镜头切换时可忽略预期跳变。",
        }
        active = False
        for name, issue_frames in issues.items():
            if not issue_frames:
                continue
            active = True
            lines.append(f"[警告] {name}：{_frame_ranges(issue_frames)}")
            lines.append(f"[处理] {advice[name]}")
        if not active:
            lines.append("[通过] 未发现灯光设置或变换的明显跳变。")
        lines.append("[处理] 本检查没有渲染像素，不能确认材质暗部闪烁或实际阴影缺块；交付前仍建议对风险范围使用最终渲染确认。")
        settings.shadow_check_report = "\n".join(lines)
        settings.shadow_check_status = "无渲染快速检查完成"
        print("\n" + settings.shadow_check_report + "\n")
        self.report({'INFO'}, f"无渲染检查完成，共采样 {len(frames)} 帧")
        return {'FINISHED'}


def _capture_shadow_fix_backup(scene):
    key = scene.as_pointer()
    if key not in _SHADOW_FIX_BACKUP:
        _SHADOW_FIX_BACKUP[key] = {
            "pool": scene.eevee.shadow_pool_size,
            "scale": scene.eevee.shadow_resolution_scale,
            "volumetric": scene.eevee.use_volumetric_shadows,
            "lights": {
                obj.name: (obj.data.use_shadow, getattr(obj.data, "use_shadow_jitter", False))
                for obj in scene.objects if obj.type == 'LIGHT'
            },
        }


class HTT_OT_apply_shadow_fix(Operator):
    bl_idname = "htt_toolbox.apply_shadow_fix"
    bl_label = "应用阴影修复"
    bl_description = "保存当前阴影设置后应用所选修复；不会修改模型，可用“恢复修改前设置”撤回"
    bl_options = {'REGISTER', 'UNDO'}

    action: EnumProperty(
        items=(
            ('POOL', "提升阴影池", "把 Shadow Pool Size 提升一级，优先推荐"),
            ('RESOLUTION', "降低阴影分辨率", "应用界面选择的全局阴影分辨率比例"),
            ('VOLUMETRIC', "关闭体积阴影", "关闭 Eevee 体积阴影，可能改变雾和体积光效果"),
            ('LIGHT_SHADOW', "关闭所选灯光投影", "关闭活动灯光的阴影，可能明显改变画面"),
            ('LIGHT_JITTER', "关闭所选灯光抖动", "关闭活动灯光 Shadow Jitter，可能改变柔和阴影"),
        ),
        options={'HIDDEN'},
    )

    def invoke(self, context, event):
        if self.action in {'VOLUMETRIC', 'LIGHT_SHADOW', 'LIGHT_JITTER'}:
            return context.window_manager.invoke_confirm(self, event)
        return self.execute(context)

    def execute(self, context):
        scene = context.scene
        settings = scene.htt_toolbox
        if scene.render.engine != _eevee_engine():
            self.report({'WARNING'}, "这些修复仅适用于 Eevee Next")
            return {'CANCELLED'}
        _capture_shadow_fix_backup(scene)

        if self.action == 'POOL':
            sizes = ('16', '32', '64', '128', '256', '512', '1024')
            current = scene.eevee.shadow_pool_size
            index = sizes.index(current)
            if index == len(sizes) - 1:
                self.report({'INFO'}, "阴影池已经是最大值 1024 MB")
                return {'CANCELLED'}
            target = sizes[index + 1]
            scene.eevee.shadow_pool_size = target
            message = f"阴影池已从 {current} MB 提升到 {target} MB"
        elif self.action == 'RESOLUTION':
            old = scene.eevee.shadow_resolution_scale
            target = float(settings.shadow_resolution_target)
            scene.eevee.shadow_resolution_scale = target
            message = f"全局阴影分辨率已从 {old:.0%} 调整为 {target:.0%}"
        elif self.action == 'VOLUMETRIC':
            scene.eevee.use_volumetric_shadows = False
            message = "已关闭体积阴影；请检查雾和体积光效果"
        else:
            obj = context.active_object
            if obj is None or obj.type != 'LIGHT':
                self.report({'WARNING'}, "请先在物体模式选择一盏次要灯光")
                return {'CANCELLED'}
            if self.action == 'LIGHT_SHADOW':
                obj.data.use_shadow = False
                message = f"已关闭灯光“{obj.name}”的投影"
            else:
                if not hasattr(obj.data, "use_shadow_jitter"):
                    self.report({'WARNING'}, "所选灯光不支持 Shadow Jitter")
                    return {'CANCELLED'}
                obj.data.use_shadow_jitter = False
                message = f"已关闭灯光“{obj.name}”的 Shadow Jitter"

        settings.shadow_check_status = message + "；建议重新检查"
        self.report({'INFO'}, message)
        return {'FINISHED'}


class HTT_OT_restore_shadow_fixes(Operator):
    bl_idname = "htt_toolbox.restore_shadow_fixes"
    bl_label = "恢复修改前设置"
    bl_description = "恢复本次修复前保存的阴影池、分辨率、体积阴影及各灯光阴影设置；不会修改模型"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.scene.as_pointer() in _SHADOW_FIX_BACKUP

    def execute(self, context):
        scene = context.scene
        backup = _SHADOW_FIX_BACKUP.pop(scene.as_pointer(), None)
        if backup is None:
            self.report({'WARNING'}, "没有可恢复的阴影设置快照")
            return {'CANCELLED'}
        scene.eevee.shadow_pool_size = backup["pool"]
        scene.eevee.shadow_resolution_scale = backup["scale"]
        scene.eevee.use_volumetric_shadows = backup["volumetric"]
        for name, (use_shadow, use_jitter) in backup["lights"].items():
            obj = scene.objects.get(name)
            if obj is None or obj.type != 'LIGHT':
                continue
            obj.data.use_shadow = use_shadow
            if hasattr(obj.data, "use_shadow_jitter"):
                obj.data.use_shadow_jitter = use_jitter
        scene.htt_toolbox.shadow_check_status = "已恢复修改前的阴影设置"
        self.report({'INFO'}, "已恢复修改前的阴影设置")
        return {'FINISHED'}


class HTT_OT_remove_selected_highlights(Operator):
    bl_idname = "htt_toolbox.remove_selected_highlights"
    bl_label = "去除所选物体高光（修改墙面）"
    bl_description = "为一个或多个所选网格建立独立材质副本并关闭高光；可分批继续处理其他网格"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and any(obj.type == 'MESH' for obj in context.selected_objects)

    def execute(self, context):
        scene_key = context.scene.as_pointer()
        scene_backups = _HIGHLIGHT_BACKUP.setdefault(scene_key, {})
        added = 0
        skipped = 0
        already_processed = 0
        for obj in [item for item in context.selected_objects if item.type == 'MESH']:
            obj_key = obj.as_pointer()
            if obj_key in scene_backups:
                already_processed += 1
                continue
            originals = [slot.material for slot in obj.material_slots]
            if not any(originals):
                skipped += 1
                continue
            original_data = obj.data
            generated_data = original_data.copy()
            obj.data = generated_data
            copies = []
            material_map = {}
            for index, original in enumerate(originals):
                if original is None:
                    continue
                copy = material_map.get(original)
                if copy is None:
                    copy = original.copy()
                    copy.name = f"{original.name}_HTT_无高光"
                    material_map[original] = copy
                    copies.append(copy)
                    copy.specular_intensity = 0.0
                    if copy.use_nodes and copy.node_tree:
                        for node in copy.node_tree.nodes:
                            if node.type != 'BSDF_PRINCIPLED':
                                continue
                            for socket_name in ("Specular IOR Level", "Coat Weight"):
                                socket = node.inputs.get(socket_name)
                                if socket is None:
                                    continue
                                for link in list(socket.links):
                                    copy.node_tree.links.remove(link)
                                socket.default_value = 0.0
                obj.material_slots[index].material = copy
            scene_backups[obj_key] = {
                "object": obj,
                "original_data": original_data,
                "generated_data": generated_data,
                "copies": copies,
            }
            added += 1
        if not scene_backups:
            _HIGHLIGHT_BACKUP.pop(scene_key, None)
        if added == 0:
            message = "所选网格没有可处理的材质"
            if already_processed:
                message = "所选网格均已关闭高光；可继续选择其他网格，或恢复当前所选网格"
            self.report({'WARNING'}, message)
            return {'CANCELLED'}
        message = f"已去除 {added} 个物体的材质高光"
        if skipped:
            message += f"；跳过 {skipped} 个无材质物体"
        if already_processed:
            message += f"；{already_processed} 个已处理物体保持不变"
        self.report({'INFO'}, message)
        return {'FINISHED'}


class HTT_OT_restore_selected_highlights(Operator):
    bl_idname = "htt_toolbox.restore_selected_highlights"
    bl_label = "恢复物体高光（修改墙面）"
    bl_description = "只恢复当前所选网格的原始材质；未选中的已处理网格保持不变"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.scene.as_pointer() in _HIGHLIGHT_BACKUP

    def execute(self, context):
        scene_key = context.scene.as_pointer()
        scene_backups = _HIGHLIGHT_BACKUP.get(scene_key)
        if not scene_backups:
            self.report({'WARNING'}, "没有可恢复的墙面高光设置")
            return {'CANCELLED'}
        selected_meshes = [obj for obj in context.selected_objects if obj.type == 'MESH']
        if not selected_meshes:
            self.report({'WARNING'}, "请先选择需要恢复高光的网格物体")
            return {'CANCELLED'}
        restored = 0
        for selected in selected_meshes:
            record = scene_backups.pop(selected.as_pointer(), None)
            if record is None:
                continue
            obj = record["object"]
            if obj and obj.name in context.scene.objects:
                obj.data = record["original_data"]
                restored += 1
            generated_data = record["generated_data"]
            if generated_data.users == 0:
                bpy.data.meshes.remove(generated_data)
            for material in record["copies"]:
                if material.users == 0:
                    bpy.data.materials.remove(material)
        if not scene_backups:
            _HIGHLIGHT_BACKUP.pop(scene_key, None)
        if restored == 0:
            self.report({'WARNING'}, "所选网格没有由插件保存的待恢复记录")
            return {'CANCELLED'}
        self.report({'INFO'}, f"已恢复 {restored} 个所选物体的原始高光材质；其他物体保持不变")
        return {'FINISHED'}


class HTT_OT_remove_selected_light_highlights(Operator):
    bl_idname = "htt_toolbox.remove_selected_light_highlights"
    bl_label = "关闭所选灯光高光（修改灯光）"
    bl_description = "关闭一个或多个所选灯光的高光贡献；可分批继续处理其他灯光，保留漫反射与阴影"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and any(obj.type == 'LIGHT' for obj in context.selected_objects)

    def execute(self, context):
        scene_key = context.scene.as_pointer()
        scene_backups = _LIGHT_HIGHLIGHT_BACKUP.setdefault(scene_key, {})
        added = 0
        already_processed = 0
        for obj in [item for item in context.selected_objects if item.type == 'LIGHT']:
            obj_key = obj.as_pointer()
            if obj_key in scene_backups:
                already_processed += 1
                continue
            original_data = obj.data
            generated_data = original_data.copy()
            generated_data.name = f"{original_data.name}_HTT_无高光"
            generated_data.specular_factor = 0.0
            obj.data = generated_data
            scene_backups[obj_key] = {
                "object": obj,
                "original_data": original_data,
                "generated_data": generated_data,
            }
            added += 1
        if added == 0:
            self.report({'WARNING'}, "所选灯光均已关闭高光；可继续选择其他灯光，或恢复当前所选灯光")
            return {'CANCELLED'}
        message = f"已关闭 {added} 盏灯的高光贡献，漫反射照明、阴影和物体材质保持不变"
        if already_processed:
            message += f"；{already_processed} 盏已处理灯光保持不变"
        self.report({'INFO'}, message)
        return {'FINISHED'}


class HTT_OT_restore_selected_light_highlights(Operator):
    bl_idname = "htt_toolbox.restore_selected_light_highlights"
    bl_label = "恢复灯光高光（修改灯光）"
    bl_description = "只恢复当前所选灯光的原始高光贡献；未选中的已处理灯光保持不变"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.scene.as_pointer() in _LIGHT_HIGHLIGHT_BACKUP

    def execute(self, context):
        scene_key = context.scene.as_pointer()
        scene_backups = _LIGHT_HIGHLIGHT_BACKUP.get(scene_key)
        if not scene_backups:
            self.report({'WARNING'}, "没有可恢复的灯光高光设置")
            return {'CANCELLED'}
        selected_lights = [obj for obj in context.selected_objects if obj.type == 'LIGHT']
        if not selected_lights:
            self.report({'WARNING'}, "请先选择需要恢复高光贡献的灯光")
            return {'CANCELLED'}
        restored = 0
        for selected in selected_lights:
            record = scene_backups.pop(selected.as_pointer(), None)
            if record is None:
                continue
            obj = record["object"]
            if obj and obj.name in context.scene.objects:
                obj.data = record["original_data"]
                restored += 1
            generated_data = record["generated_data"]
            if generated_data.users == 0:
                bpy.data.lights.remove(generated_data)
        if not scene_backups:
            _LIGHT_HIGHLIGHT_BACKUP.pop(scene_key, None)
        if restored == 0:
            self.report({'WARNING'}, "所选灯光没有由插件保存的待恢复记录")
            return {'CANCELLED'}
        self.report({'INFO'}, f"已恢复 {restored} 盏所选灯光的原始高光贡献；其他灯光保持不变")
        return {'FINISHED'}


class HTT_OT_exclude_light_receivers(Operator):
    bl_idname = "htt_toolbox.exclude_light_receivers"
    bl_label = "排除所选物体（灯光链接）"
    bl_description = "同时选中一盏灯和一个或多个目标物体；目标会失去该灯的整体影响。Blender 4.5 以下仅支持 Cycles 渲染器，4.5 支持 Eevee 和 Cycles；随后可一键恢复"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        scene_key = context.scene.as_pointer()
        if bpy.app.version < (4, 5, 0) and context.scene.render.engine != 'CYCLES':
            self.report({'WARNING'}, "Blender 4.5 以下版本的灯光链接仅支持 Cycles 渲染器；当前 Eevee 不会生效")
            return {'CANCELLED'}
        selected = list(context.selected_objects)
        selected_lights = [obj for obj in selected if obj.type == 'LIGHT']
        active = context.active_object
        if active is not None and active.type == 'LIGHT' and active in selected_lights:
            emitter = active
        elif len(selected_lights) == 1:
            emitter = selected_lights[0]
            context.view_layer.objects.active = emitter
        elif not selected_lights:
            self.report({'WARNING'}, "请同时选中一盏灯和至少一个需要排除的目标物体")
            return {'CANCELLED'}
        else:
            self.report({'WARNING'}, "选中了多盏灯，请最后单击其中一盏，使它成为活动灯光")
            return {'CANCELLED'}
        receivers = [obj for obj in selected if obj != emitter]
        if not receivers:
            self.report({'WARNING'}, "目前只选中了灯光；请再选中至少一个需要排除的目标物体")
            return {'CANCELLED'}
        scene_backups = _LIGHT_LINK_BACKUP.setdefault(scene_key, {})
        emitter_key = emitter.as_pointer()
        if emitter_key in scene_backups:
            self.report({'WARNING'}, f"灯光“{emitter.name}”已有待恢复记录；请先恢复该灯光后再重新处理")
            return {'CANCELLED'}
        original_collection = emitter.light_linking.receiver_collection
        if original_collection is None:
            generated_collection = bpy.data.collections.new(f"{emitter.name}_HTT_灯光排除")
        else:
            generated_collection = original_collection.copy()
            generated_collection.name = f"{original_collection.name}_HTT_灯光排除"
        emitter.light_linking.receiver_collection = generated_collection
        result = bpy.ops.object.light_linking_receivers_link(link_state='EXCLUDE')
        if result != {'FINISHED'}:
            emitter.light_linking.receiver_collection = original_collection
            if generated_collection.users == 0:
                bpy.data.collections.remove(generated_collection)
            if not scene_backups:
                _LIGHT_LINK_BACKUP.pop(scene_key, None)
            self.report({'ERROR'}, "灯光链接排除失败，请确认已同时选中灯光和目标物体")
            return {'CANCELLED'}
        scene_backups[emitter_key] = {
            "emitter": emitter,
            "original_collection": original_collection,
            "generated_collection": generated_collection,
        }
        self.report({'INFO'}, f"已将 {len(receivers)} 个物体排除在灯光“{emitter.name}”的整体影响之外")
        return {'FINISHED'}


class HTT_OT_restore_light_receivers(Operator):
    bl_idname = "htt_toolbox.restore_light_receivers"
    bl_label = "恢复所选灯光（灯光链接）"
    bl_description = "只恢复当前所选灯光中由插件修改过的灯光链接；未选中的灯光保持不变，可一次选择并恢复多盏灯"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.scene.as_pointer() in _LIGHT_LINK_BACKUP

    def execute(self, context):
        scene_key = context.scene.as_pointer()
        scene_backups = _LIGHT_LINK_BACKUP.get(scene_key)
        if not scene_backups:
            self.report({'WARNING'}, "没有可恢复的灯光链接设置")
            return {'CANCELLED'}
        selected_lights = [obj for obj in context.selected_objects if obj.type == 'LIGHT']
        if not selected_lights:
            self.report({'WARNING'}, "请先选择需要恢复灯光链接的灯光")
            return {'CANCELLED'}
        restored = 0
        for emitter in selected_lights:
            backup = scene_backups.pop(emitter.as_pointer(), None)
            if backup is None:
                continue
            emitter.light_linking.receiver_collection = backup["original_collection"]
            generated_collection = backup["generated_collection"]
            if generated_collection.users == 0:
                bpy.data.collections.remove(generated_collection)
            restored += 1
        if not scene_backups:
            _LIGHT_LINK_BACKUP.pop(scene_key, None)
        if restored == 0:
            self.report({'WARNING'}, "所选灯光没有由插件保存的待恢复记录")
            return {'CANCELLED'}
        self.report({'INFO'}, f"已恢复 {restored} 盏所选灯光的链接设置；其他灯光保持不变")
        return {'FINISHED'}


_PANEL_STATE_ID = "1-8KnNHaCslT2jQPRhmGCsOjKZ0veST5ei28"


def _validate_internal_schema():
    values = (
        _DATA_LAYOUT_REV,
        _RANGE_TABLE_ID,
        _TOPOLOGY_CACHE_ID,
        _ANALYSIS_DATA_ID,
        _FIELD_PROFILE_ID,
        _VOXEL_LAYOUT_ID,
        _PANEL_STATE_ID,
    )
    actual = hashlib.sha256("|".join(values).encode("ascii")).hexdigest()
    return actual == _INTERNAL_SCHEMA_DIGEST


class HTT_PT_toolbox(Panel):
    bl_label = "HTT 工具箱"
    bl_idname = "HTT_PT_toolbox"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "htt工具箱"

    def draw(self, context):
        layout = self.layout
        header = layout.box()
        row = header.row()
        row.alignment = 'CENTER'
        row.label(text=f"HTT Toolbox  v{ADDON_VERSION}  |  花提提")
        row = header.row()
        row.alignment = 'CENTER'
        row.label(text="抖音：提提大王！  |  QQ群：1067456638")


class HTT_PT_render_test(Panel):
    bl_label = "1. 渲染测试"
    bl_idname = "HTT_PT_render_test"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "htt工具箱"
    bl_parent_id = "HTT_PT_toolbox"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        settings = context.scene.htt_toolbox
        layout.prop(settings, "render_test_mode", expand=True)
        layout.prop(settings, "render_output_dir")
        if settings.render_test_mode == 'SINGLE':
            layout.prop(settings, "render_test_frame")
            layout.operator("htt_toolbox.render_test", text="渲染单帧 PNG", icon='RENDER_STILL')
        else:
            row = layout.row(align=True)
            row.prop(settings, "render_range_start")
            row.prop(settings, "render_range_end")
            layout.prop(settings, "render_range_format", expand=True)
            label = "渲染 PNG 序列" if settings.render_range_format == 'PNG' else "渲染 MOV 视频"
            layout.operator("htt_toolbox.render_test", text=label, icon='RENDER_ANIMATION')
        layout.label(text="使用当前引擎与采样；完成后恢复项目输出设置", icon='INFO')


class HTT_PT_shadow_check(Panel):
    bl_label = "2. 最终画面阴影检查"
    bl_idname = "HTT_PT_shadow_check"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "htt工具箱"
    bl_parent_id = "HTT_PT_toolbox"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        settings = context.scene.htt_toolbox
        layout.label(text="无需选择物体，按最终相机检查整幅画面", icon='CAMERA_DATA')
        row = layout.row(align=True)
        row.prop(settings, "shadow_check_start")
        row.prop(settings, "shadow_check_end")
        layout.prop(settings, "shadow_check_quality", expand=True)
        layout.prop(settings, "shadow_flicker_sensitivity")
        layout.operator("htt_toolbox.check_shadow_fast", text="无渲染快速检查", icon='PLAY')
        layout.operator("htt_toolbox.check_shadow_range", text="最终渲染确认（较慢）", icon='RENDER_STILL')
        layout.label(text="先快速检查；最终确认才会实际渲染", icon='INFO')
        if settings.shadow_check_status:
            layout.label(text=settings.shadow_check_status, icon='TIME')
        if settings.shadow_check_report:
            result = layout.box()
            for line in settings.shadow_check_report.splitlines():
                icon = 'ERROR' if line.startswith("[警告]") else ('INFO' if line.startswith("[处理]") else 'CHECKMARK')
                result.label(text=line, icon=icon)

            fixes = layout.box()
            fixes.label(text="修改选项（按推荐顺序）", icon='TOOL_SETTINGS')
            fixes.label(text="1. 优先：增加显存中的阴影池", icon='MEMORY')
            op = fixes.operator("htt_toolbox.apply_shadow_fix", text="阴影池提升一级", icon='ADD')
            op.action = 'POOL'

            fixes.separator()
            fixes.label(text="2. 其次：降低全局阴影分辨率", icon='IMAGE_DATA')
            fixes.prop(settings, "shadow_resolution_target")
            op = fixes.operator("htt_toolbox.apply_shadow_fix", text="应用阴影分辨率", icon='CHECKMARK')
            op.action = 'RESOLUTION'

            alternatives = fixes.column(align=True)
            alternatives.label(text="备选（会改变画面，请先选择次要灯光）", icon='ERROR')
            op = alternatives.operator("htt_toolbox.apply_shadow_fix", text="关闭体积阴影")
            op.action = 'VOLUMETRIC'
            op = alternatives.operator("htt_toolbox.apply_shadow_fix", text="关闭所选灯光投影")
            op.action = 'LIGHT_SHADOW'
            op = alternatives.operator("htt_toolbox.apply_shadow_fix", text="关闭所选灯光抖动")
            op.action = 'LIGHT_JITTER'

            row = fixes.row(align=True)
            row.operator("htt_toolbox.restore_shadow_fixes", icon='LOOP_BACK')
            row.operator("htt_toolbox.check_shadow_range", text="重新检查", icon='FILE_REFRESH')


class HTT_PT_highlight_control(Panel):
    bl_label = "3. 高光亮斑处理"
    bl_idname = "HTT_PT_highlight_control"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "htt工具箱"
    bl_parent_id = "HTT_PT_toolbox"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        layout.label(text="方案一：选择出现亮斑的墙面", icon='MATERIAL')
        layout.operator("htt_toolbox.remove_selected_highlights", icon='SHADING_SOLID')
        layout.operator("htt_toolbox.restore_selected_highlights", icon='LOOP_BACK')
        layout.separator()
        layout.label(text="方案二：选择造成亮斑的灯光", icon='LIGHT')
        layout.operator("htt_toolbox.remove_selected_light_highlights", icon='LIGHT')
        layout.operator("htt_toolbox.restore_selected_light_highlights", icon='LOOP_BACK')
        layout.separator()
        layout.label(text="方案三：同时选择一盏灯和目标物体", icon='LINKED')
        layout.operator("htt_toolbox.exclude_light_receivers", icon='UNLINKED')
        layout.operator("htt_toolbox.restore_light_receivers", icon='LOOP_BACK')
        layout.label(text="会排除该灯的整体影响，不只排除高光", icon='ERROR')
        if bpy.app.version < (4, 5, 0):
            layout.label(text="4.5 以下仅支持 Cycles 渲染器", icon='INFO')
        else:
            layout.label(text="4.5 支持 Eevee 和 Cycles", icon='INFO')
        layout.label(text="优先推荐修改灯光，不影响物体材质", icon='INFO')


classes = (
    HTT_ToolboxSettings,
    HTT_OT_render_test,
    HTT_OT_check_shadow_range,
    HTT_OT_check_shadow_fast,
    HTT_OT_apply_shadow_fix,
    HTT_OT_restore_shadow_fixes,
    HTT_OT_remove_selected_highlights,
    HTT_OT_restore_selected_highlights,
    HTT_OT_remove_selected_light_highlights,
    HTT_OT_restore_selected_light_highlights,
    HTT_OT_exclude_light_receivers,
    HTT_OT_restore_light_receivers,
    HTT_PT_toolbox,
    HTT_PT_render_test,
    HTT_PT_shadow_check,
    HTT_PT_highlight_control,
)


def register():
    if not _validate_internal_schema():
        raise RuntimeError("HTT Toolbox internal schema validation failed")
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.htt_toolbox = PointerProperty(type=HTT_ToolboxSettings)


def unregister():
    if hasattr(bpy.types.Scene, "htt_toolbox"):
        del bpy.types.Scene.htt_toolbox
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
